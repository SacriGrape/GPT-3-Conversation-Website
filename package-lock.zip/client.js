"use strict";
exports.__esModule = true;
// import Express, obviously
var express = require('express');
var openai_1 = require("openai");
// create a new Express app, idk they included the port in a const here in the example but you don't have to obviously
var app = express();
var port = 3000;
// use the JSON middleware which just lets you uhhhh... get JSON from POST requests I think?
app.use(express.json());
// create a new GET route for / that returns the HTML file
app.get('/', function (req, res) {
    res.sendFile('./index.html', { root: __dirname });
});
// create a new POST route for /api/generate which is our API endpoint, this will generate a text completion
app.post('/api/generate', function (req, res) {
    var prompt = req.body.charDesc + "\n\n";
    for (var _i = 0, _a = req.body.questions; _i < _a.length; _i++) {
        var question = _a[_i];
        prompt += "Question: " + question.question + "\nResponse: " + question.response + "\n\n";
    }
    console.log(prompt);
    var configuration = new openai_1.Configuration({
        apiKey: req.body.apiKey
    });
    var openai = new openai_1.OpenAIApi(configuration);
    openai.createCompletion("text-davinci-001", {
        "prompt": prompt,
        "temperature": 0.5,
        "max_tokens": 1600
    }).then(function (r) {
        res.send(r.data.choices[0].text);
    });
});
// start the server
app.listen(port, function () {
    console.log("Listening on port " + port);
});
